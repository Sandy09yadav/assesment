import React, { useEffect, useRef, useCallback } from 'react'
import useUserStore from '../store/userStore'

const UserTable = () => {
  const { users, loading, hasMore, fetchUsers, selectUser, isDrawerOpen } = useUserStore()
  const observer = useRef()

  // Intersection Observer for infinite scrolling
  const lastUserElementRef = useCallback(node => {
    if (loading) return
    if (observer.current) observer.current.disconnect()
    observer.current = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting && hasMore) {
        fetchUsers()
      }
    })
    if (node) observer.current.observe(node)
  }, [loading, hasMore, fetchUsers])

  // Initial load
  useEffect(() => {
    if (users.length === 0) {
      fetchUsers(true)
    }
  }, [users.length, fetchUsers])

  const handleRowClick = (user) => {
    selectUser(user)
  }

  return (
    <div className="h-full flex flex-col w-full">
      <div className="flex-1 overflow-auto">
        <table className="w-full bg-white table-auto">
          <thead className="bg-gray-50 border-b border-gray-200 sticky top-0 z-10">
            <tr>
              <th className={`px-4 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider ${isDrawerOpen ? 'w-[8%]' : 'w-[10%]'}`}>
                ID
              </th>
              <th className={`px-4 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider ${isDrawerOpen ? 'w-[15%]' : 'w-[15%]'}`}>
                First Name
              </th>
              <th className={`px-4 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider ${isDrawerOpen ? 'w-[15%]' : 'w-[15%]'}`}>
                Last Name
              </th>
              <th className={`px-4 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider ${isDrawerOpen ? 'w-[12%]' : 'w-[15%]'}`}>
                Username
              </th>
              <th className={`px-4 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider ${isDrawerOpen ? 'w-[25%]' : 'w-[25%]'}`}>
                Email
              </th>
              <th className={`px-4 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider ${isDrawerOpen ? 'w-[15%]' : 'w-[15%]'}`}>
                Phone
              </th>
              <th className={`px-4 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider ${isDrawerOpen ? 'w-[10%]' : 'w-[5%]'}`}>
                IP
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {users.map((user, index) => {
              const isLast = users.length === index + 1
              return (
                <tr
                  key={user.id}
                  ref={isLast ? lastUserElementRef : null}
                  onClick={() => handleRowClick(user)}
                  className="hover:bg-gray-50 cursor-pointer transition-colors duration-150"
                >
                  <td className="px-4 py-4 text-sm text-gray-900 truncate">
                    {user.id}
                  </td>
                  <td className="px-4 py-4 text-sm text-gray-900 truncate">
                    {user.firstName}
                  </td>
                  <td className="px-4 py-4 text-sm text-gray-900 truncate">
                    {user.lastName}
                  </td>
                  <td className="px-4 py-4 text-sm text-gray-900 truncate">
                    {user.username}
                  </td>
                  <td className="px-4 py-4 text-sm text-blue-600 hover:text-blue-800 truncate">
                    {user.email}
                  </td>
                  <td className="px-4 py-4 text-sm text-gray-900 truncate">
                    {user.phone}
                  </td>
                  <td className="px-4 py-4 text-sm text-gray-500 truncate">
                    {user.ip}
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
        
        {loading && (
          <div className="flex justify-center items-center py-8">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
            <span className="ml-2 text-gray-600 text-sm">Loading more users...</span>
          </div>
        )}
        
        {!hasMore && users.length > 0 && (
          <div className="text-center py-8 text-gray-500 text-sm">
            No more users to load
          </div>
        )}
      </div>
    </div>
  )
}

export default UserTable 