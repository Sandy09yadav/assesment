import React, { useState, useEffect } from 'react'
import useUserStore from '../store/userStore'

const UserDrawer = () => {
  const { selectedUser, isDrawerOpen, closeDrawer } = useUserStore()
  const [imageError, setImageError] = useState(false)

  // Reset image error when user changes
  useEffect(() => {
    setImageError(false)
  }, [selectedUser?.id])

  if (!selectedUser || !isDrawerOpen) return null

  const handleImageError = () => {
    setImageError(true)
  }

  const handleImageLoad = () => {
    setImageError(false)
  }

  const showImage = selectedUser.image && !imageError

  return (
    <div className="h-full bg-white border-l border-gray-200 flex flex-col">
      {/* Header with Back Arrow */}
      <div className="flex items-center py-1 px-4 border-b border-gray-200 bg-gray-50 flex-shrink-0">
        <button
          onClick={closeDrawer}
          className="p-2 hover:bg-gray-100 rounded-full transition-colors"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
      </div>

      {/* Content */}
      <div className="p-4 overflow-y-auto flex-1">
        {/* User Avatar and Basic Info */}
        <div className="text-center mb-6">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-teal-500 rounded-full mx-auto mb-3 flex items-center justify-center overflow-hidden">
            {showImage ? (
              <img
                src={selectedUser.image}
                alt={`${selectedUser.firstName} ${selectedUser.lastName}`}
                className="w-full h-full object-cover"
                onError={handleImageError}
                onLoad={handleImageLoad}
              />
            ) : (
              <span className="text-lg font-bold text-white">
                {selectedUser.firstName?.[0]}{selectedUser.lastName?.[0]}
              </span>
            )}
          </div>
          <h3 className="text-lg font-semibold text-gray-900">
            {selectedUser.firstName} {selectedUser.lastName}
          </h3>
          <p className="text-gray-600 text-sm">{selectedUser.username}</p>
        </div>

        {/* Personal Information */}
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1">Age</label>
            <p className="text-gray-900 text-sm">{selectedUser.age || 'N/A'}</p>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1">Blood Group</label>
            <p className="text-gray-900 text-sm">{selectedUser.bloodGroup || 'N/A'}</p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Height</label>
              <p className="text-gray-900 text-sm">{selectedUser.height ? `${selectedUser.height} cm` : 'N/A'}</p>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Weight</label>
              <p className="text-gray-900 text-sm">{selectedUser.weight ? `${selectedUser.weight} kg` : 'N/A'}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Eye Color</label>
              <p className="text-gray-900 text-sm">{selectedUser.eyeColor || 'N/A'}</p>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Hair Color</label>
              <p className="text-gray-900 text-sm">{selectedUser.hair?.color || 'N/A'}</p>
            </div>
          </div>

          {/* Contact Information */}
          <div className="border-t pt-4 mt-4">
            <h4 className="font-medium text-gray-900 mb-3 text-sm">Contact Information</h4>
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Email</label>
                <p className="text-blue-600 text-xs break-all">{selectedUser.email}</p>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Phone</label>
                <p className="text-gray-900 text-xs">{selectedUser.phone}</p>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">IP Address</label>
                <p className="text-gray-900 text-xs">{selectedUser.ip}</p>
              </div>
            </div>
          </div>

          {/* Address Information */}
          {selectedUser.address && (
            <div className="border-t pt-4 mt-4">
              <h4 className="font-medium text-gray-900 mb-3 text-sm">Address</h4>
              <div className="space-y-2">
                <p className="text-gray-900 text-xs">{selectedUser.address.address}</p>
                <p className="text-gray-900 text-xs">
                  {selectedUser.address.city}, {selectedUser.address.state} {selectedUser.address.postalCode}
                </p>
                <p className="text-gray-900 text-xs">{selectedUser.address.country}</p>
              </div>
            </div>
          )}

          {/* Company Information */}
          {selectedUser.company && (
            <div className="border-t pt-4 mt-4">
              <h4 className="font-medium text-gray-900 mb-3 text-sm">Company</h4>
              <div className="space-y-2">
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Company</label>
                  <p className="text-gray-900 text-xs">{selectedUser.company.name}</p>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Department</label>
                  <p className="text-gray-900 text-xs">{selectedUser.company.department}</p>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Title</label>
                  <p className="text-gray-900 text-xs">{selectedUser.company.title}</p>
                </div>
              </div>
            </div>
          )}

          {/* University */}
          {selectedUser.university && (
            <div className="border-t pt-4 mt-4">
              <h4 className="font-medium text-gray-900 mb-3 text-sm">Education</h4>
              <p className="text-gray-900 text-xs">{selectedUser.university}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default UserDrawer 