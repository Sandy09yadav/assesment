import React from 'react'
import UserTable from './components/UserTable'
import UserDrawer from './components/UserDrawer'
import useUserStore from './store/userStore'
import './App.css'

function App() {
  const { isDrawerOpen } = useUserStore()

  return (
    <div className="h-screen bg-gray-100">
      {/* Main Content */}
      <main className="h-full p-4">
        <div className="bg-white rounded-lg shadow-sm overflow-hidden h-full">
          <div className="flex h-full w-full">
            {/* Table Container */}
            <div className={`${isDrawerOpen ? 'w-[70%]' : 'w-full'} transition-all duration-300 border-r border-gray-200`}>
              <UserTable />
            </div>
            
            {/* User Details Drawer */}
            {isDrawerOpen && (
              <div className="w-[30%] transition-all duration-300">
                <UserDrawer />
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}

export default App
