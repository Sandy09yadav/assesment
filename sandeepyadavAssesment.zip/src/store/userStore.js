import { create } from 'zustand'

const useUserStore = create((set, get) => ({
  users: [],
  selectedUser: null,
  isDrawerOpen: false,
  loading: false,
  hasMore: true,
  skip: 0,
  limit: 30,

  // Fetch users from API
  fetchUsers: async (reset = false) => {
    const { skip, limit, users, hasMore } = get()
    
    if (!hasMore && !reset) return
    
    set({ loading: true })
    
    try {
      const currentSkip = reset ? 0 : skip
      const response = await fetch(
        `https://dummyjson.com/users?limit=${limit}&skip=${currentSkip}`
      )
      const data = await response.json()
      
      set({
        users: reset ? data.users : [...users, ...data.users],
        skip: currentSkip + limit,
        hasMore: data.users.length === limit,
        loading: false
      })
    } catch (error) {
      console.error('Error fetching users:', error)
      set({ loading: false })
    }
  },

  // Set selected user and open drawer
  selectUser: (user) => set({ selectedUser: user, isDrawerOpen: true }),

  // Close drawer
  closeDrawer: () => set({ isDrawerOpen: false, selectedUser: null }),

  // Reset store
  reset: () => set({
    users: [],
    selectedUser: null,
    isDrawerOpen: false,
    loading: false,
    hasMore: true,
    skip: 0
  })
}))

export default useUserStore 